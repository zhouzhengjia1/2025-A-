import matplotlib.pyplot as plt
import numpy as np
import time


class Param:
    def __init__(self):
        def get_Delta_M(M):
            return (
                -M[0] / np.linalg.norm(M),
                -M[1] / np.linalg.norm(M),
                -M[2] / np.linalg.norm(M),
            )

        # 导弹坐标
        self.M1 = (20000, 0, 2000)
        self.Delta_M1 = get_Delta_M(self.M1)
        self.M2 = (19000, 600, 2100)
        self.Delta_M2 = get_Delta_M(self.M2)
        self.M3 = (18000, -600, 1900)
        self.Delta_M3 = get_Delta_M(self.M3)

        # 导弹速度
        self.v_M = 300
        # 最大时间为导弹打中原点的时间
        self.max_t = (
            np.min(
                [
                    np.linalg.norm(self.M1),
                    np.linalg.norm(self.M2),
                    np.linalg.norm(self.M3),
                ]
            )
            / self.v_M
        )

        # 无人机坐标
        self.FY1 = (17800, 0, 1800)
        self.FY2 = (12000, 1400, 1400)
        self.FY3 = (6000, -3000, 700)
        self.FY4 = (11000, 2000, 1800)
        self.FY5 = (13000, -2000, 1300)
        self.FY_v_max = 140
        self.FY_v_min = 70

        # 云团半径
        self.r_YT = 10
        # 云团遮蔽时间
        self.t_YT = 20
        # 云团下降速度
        self.v_YT = 3
        # 云团遮蔽判断采样点数，在圆柱圆心采样
        self.shield_check_N = 50

        # 圆柱圆心坐标
        self.R = 7
        self.C1 = (0, 200, 0)
        self.C1_sample_point_list = [
            (
                self.C1[0] + self.R * np.cos(2 * np.pi / self.shield_check_N * i),
                self.C1[1] + self.R * np.sin(2 * np.pi / self.shield_check_N * i),
                self.C1[2],
            )
            for i in range(self.shield_check_N)
        ]
        self.C2 = (0, 200, 10)
        self.C2_sample_point_list = [
            (
                self.C2[0] + self.R * np.cos(2 * np.pi / self.shield_check_N * i),
                self.C2[1] + self.R * np.sin(2 * np.pi / self.shield_check_N * i),
                self.C2[2],
            )
            for i in range(self.shield_check_N)
        ]

        # 重力加速度
        self.g = 9.8

    def get_M_pos(self, M, Delta_M, t):
        return (
            M[0] + Delta_M[0] * self.v_M * t,
            M[1] + Delta_M[1] * self.v_M * t,
            M[2] + Delta_M[2] * self.v_M * t,
        )

    def is_point_in_sphere(self, point, sphere_center, radius):
        """
        判断点是否在球内
        """
        distance = np.linalg.norm(np.array(point) - np.array(sphere_center))
        return distance <= radius

    def line_segment_sphere_intersection(self, point1, point2, sphere_center, radius):
        """
        判断线段是否与球相交（被遮蔽）
        满足以下条件之一即为被遮蔽：
        1. 两端点任意一点在球内
        2. 线段上距离球心最近的点在球内

        :param point1: 线段起点
        :param point2: 线段终点
        :param sphere_center: 球心坐标
        :param radius: 球半径
        :return: True表示被遮蔽，False表示未被遮蔽
        """
        p1 = np.array(point1)
        p2 = np.array(point2)
        center = np.array(sphere_center)

        # 条件1：检查两端点是否在球内
        if self.is_point_in_sphere(p1, center, radius) or self.is_point_in_sphere(
            p2, center, radius
        ):
            return True

        # 条件2：找到线段上距离球心最近的点
        # 线段的方向向量
        line_vec = p2 - p1
        line_length_squared = np.dot(line_vec, line_vec)

        # 如果线段长度为0（两点重合），直接检查该点
        if line_length_squared < 1e-10:
            return self.is_point_in_sphere(p1, center, radius)

        # 从起点到球心的向量
        to_center = center - p1

        # 计算投影参数t，t=0时为起点，t=1时为终点
        t = np.dot(to_center, line_vec) / line_length_squared

        # 将t限制在[0,1]范围内，确保最近点在线段上
        t = max(0, min(1, t))

        # 计算线段上最近的点
        closest_point = p1 + t * line_vec

        # 判断最近点是否在球内
        return self.is_point_in_sphere(closest_point, center, radius)

    def check_is_shield(self, YT_pos, M_pos):
        """
        检测导弹是否被云团完全遮蔽
        对圆柱的每个采样点，检测从采样点到导弹的线段是否被云团遮蔽
        只有当所有线段都被遮蔽时，才认为被完全遮挡

        :param YT_pos: 云团球心坐标
        :param M_pos: 导弹坐标
        :return: (是否被遮蔽, 调试信息)
        """
        # 检查两组采样点
        all_sample_points = self.C1_sample_point_list + self.C2_sample_point_list

        # 检查每个采样点到导弹的线段是否被云团遮蔽
        for sample_point in all_sample_points:
            # 检查从采样点到导弹的线段是否被云团遮蔽
            if not self.line_segment_sphere_intersection(
                sample_point, M_pos, YT_pos, self.r_YT
            ):
                # 如果有任何一条线段未被遮蔽，则整体未被完全遮蔽
                return False, [sample_point, M_pos, YT_pos]

        # 所有线段都被遮蔽，认为被完全遮挡
        return True, []


param = Param()


class GeneralN1:
    def __init__(self, FY1_theta, t_drop, t_boom, v_FY1) -> None:
        # 无人机朝向
        self.FY1_theta = FY1_theta
        # 投放炸弹的时间
        self.t_drop = t_drop
        # 投放后炸弹释放云团的间隔时间
        self.t_boom = t_boom
        # 无人机速度
        self.v_FY1 = v_FY1

        self.t_min = self.t_drop + self.t_boom
        self.t_max = self.t_min + param.t_YT

        self.approx_eps = 1e-5

    def get_YT_pos(self, t):
        return (
            param.FY1[0] + np.cos(self.FY1_theta) * self.v_FY1 * self.t_min,
            param.FY1[1] + np.sin(self.FY1_theta) * self.v_FY1 * self.t_min,
            param.FY1[2]
            - 0.5 * param.g * self.t_boom**2
            - param.v_YT * (t - self.t_min),
        )

    def find_t_approx(self):
        """
        以一秒为精度，返回每隔一秒是否被遮蔽
        """
        results = []
        for t in np.arange(self.t_min, self.t_max, 0.1):
            YT_pos = self.get_YT_pos(t)
            M_pos = param.get_M_pos(param.M1, param.Delta_M1, t)
            is_shielded, _ = param.check_is_shield(YT_pos, M_pos)
            results.append((t, is_shielded))
        return results

    def find_t(self):
        """
        结合粗判断和二分法在t_min和t_max之间寻找最小和最大的t，使得导弹被云团完全遮蔽
        """
        # 先进行粗判断
        approx_results = self.find_t_approx()

        # 找到第一个和最后一个被遮蔽的时间点
        shielded_times = [t for t, is_shielded in approx_results if is_shielded]

        if not shielded_times:
            return None, None, 0  # 没有被遮蔽的时间

        # 获取粗略的开始和结束时间范围
        rough_start = shielded_times[0]
        rough_end = shielded_times[-1]

        # 扩展搜索范围，确保二分法能找到准确边界
        search_margin = 1.0

        # 找到最小的t（二分法精确搜索）
        left = max(self.t_min, rough_start - search_margin)
        right = rough_start + search_margin
        while right - left > self.approx_eps:
            mid = (left + right) / 2
            YT_pos = self.get_YT_pos(mid)
            M_pos = param.get_M_pos(param.M1, param.Delta_M1, mid)
            if param.check_is_shield(YT_pos, M_pos)[0]:
                right = mid
            else:
                left = mid
        t_min_found = (left + right) / 2

        # 找到最大的t（二分法精确搜索）
        left = rough_end - search_margin
        right = min(self.t_max, rough_end + search_margin)
        while right - left > self.approx_eps:
            mid = (left + right) / 2
            YT_pos = self.get_YT_pos(mid)
            M_pos = param.get_M_pos(param.M1, param.Delta_M1, mid)
            if param.check_is_shield(YT_pos, M_pos)[0]:
                left = mid
            else:
                right = mid
        t_max_found = (left + right) / 2

        return t_min_found, t_max_found, t_max_found - t_min_found


t1 = GeneralN1(FY1_theta=np.pi, t_drop=1.5, t_boom=3.6, v_FY1=120)

approx_results = t1.find_t_approx()

# 提取时间和遮蔽状态数据
times = [t for t, _ in approx_results]
shielded_status = [1 if is_shielded else 0 for _, is_shielded in approx_results]

# 设置中文字体支持
plt.rcParams["font.sans-serif"] = ["SimHei"]  # 用来正常显示中文标签
plt.rcParams["axes.unicode_minus"] = False  # 用来正常显示负号

# 创建图形
plt.figure(figsize=(12, 6))
plt.plot(times, shielded_status, "b-", linewidth=2, label="遮蔽状态")
plt.fill_between(times, shielded_status, alpha=0.3, color="blue")

plt.xlabel("时间 (秒)")
plt.ylabel("遮蔽状态")
plt.title("导弹被云团遮蔽状态随时间变化")
plt.grid(True, alpha=0.3)
plt.legend()
plt.ylim(-0.1, 1.1)
plt.yticks([0, 1], ["未遮蔽", "被遮蔽"])

# 设置x轴间隔为1
plt.xticks(range(int(min(times)), int(max(times)) + 2))

plt.tight_layout()
plt.show()

t_min, t_max, duration = t1.find_t()

print(f"最小t: {t_min:.6f}, 最大t: {t_max:.6f}, 持续时间: {duration:.6f}")


import numpy as np
import warnings

warnings.filterwarnings("ignore")


class PreciseOptimizer:
    def __init__(self):
        self.phi = (1 + np.sqrt(5)) / 2  # 黄金比例
        self.resphi = 2 - self.phi  # 1/φ

    def golden_section_search_1d(self, func, a, b, tol=1e-6, max_iter=100):
        """
        一维黄金分割搜索求最大值

        func : callable
            一维目标函数
        a, b : float
            搜索区间
        tol : float
            精度要求
        max_iter : int
            最大迭代次数
        """
        x1 = a + self.resphi * (b - a)
        x2 = b - self.resphi * (b - a)
        f1 = func(x1)
        f2 = func(x2)

        for iteration in range(max_iter):
            if abs(b - a) < tol:
                return (a + b) / 2, func((a + b) / 2), iteration + 1

            if f1 > f2:  # 求最大值
                b = x2
                x2 = x1
                f2 = f1
                x1 = a + self.resphi * (b - a)
                f1 = func(x1)
            else:
                a = x1
                x1 = x2
                f1 = f2
                x2 = b - self.resphi * (b - a)
                f2 = func(x2)

        optimal_x = (a + b) / 2
        return optimal_x, func(optimal_x), max_iter

    def coordinate_optimization(
        self,
        objective_func,
        bounds,
        tol=1e-6,
        max_iter=100,
        max_cycles=50,
        verbose=True,
        callback=None,
    ):
        """
        坐标搜索法结合黄金分割搜索进行多元函数优化

        objective_func : callable
            目标函数，接受numpy数组作为输入，返回标量值

        bounds : list of tuples
            每个变量的搜索边界，格式为[(min1, max1), (min2, max2), ...]

        tol : float, default=1e-6
            收敛精度

        max_iter : int, default=100
            每个维度的最大迭代次数

        max_cycles : int, default=50
            最大循环次数（轮次）

        verbose : bool, default=True
            是否打印优化过程

        callback : callable, default=None
            每次迭代后的回调函数

        Returns
        -------
        result : dict
            优化结果
        """

        dim = len(bounds)
        bounds = np.array(bounds)

        # 初始化为区间中点
        x = np.array([(a + b) / 2 for a, b in bounds])

        # 存储历史
        X_iters = [x.copy()]
        func_vals = [objective_func(x)]

        if verbose:
            print(f"初始点: {x}")
            print(f"初始函数值: {func_vals[0]:.6f}")
            print(f"\n开始坐标搜索优化...")

        for cycle in range(max_cycles):
            x_old = x.copy()
            cycle_improved = False

            # 对每个维度进行优化
            for i in range(dim):
                # 定义当前维度的一维函数
                def univariate_func(xi):
                    temp_x = x.copy()
                    temp_x[i] = xi
                    return objective_func(temp_x)

                # 在当前维度上进行黄金分割搜索
                x_new_i, f_new_i, iter_count = self.golden_section_search_1d(
                    univariate_func, bounds[i][0], bounds[i][1], tol, max_iter
                )

                # 更新当前维度的值
                if f_new_i > objective_func(x):  # 如果有改进
                    x[i] = x_new_i
                    cycle_improved = True

                    if verbose:
                        print(
                            f"轮次 {cycle+1}, 维度 {i+1}: "
                            f"x[{i}] = {x[i]:.6f}, f = {f_new_i:.6f}, "
                            f"迭代次数: {iter_count}"
                        )
                else:
                    # 没有改进
                    if verbose:
                        original_f = objective_func(x)
                        print(
                            f"轮次 {cycle+1}, 维度 {i+1}: "
                            f"无改进，保持 x[{i}] = {x[i]:.6f}, f = {original_f:.6f}"
                        )
                        print(
                            f"  找到的优化点: x[{i}] = {x_new_i:.6f}, f = {f_new_i:.6f}"
                        )
                        print(f"  原本的点: x[{i}] = {x[i]:.6f}, f = {original_f:.6f}")

                # 记录历史
                X_iters.append(x.copy())
                func_vals.append(objective_func(x))

                # 回调函数
                if callback is not None:
                    callback(x.copy(), func_vals[-1], len(func_vals) - 1)

            # 检查收敛
            improvement = np.linalg.norm(x - x_old)

            if verbose:
                current_f = objective_func(x)
                print(
                    f"轮次 {cycle+1} 完成: f = {current_f:.6f}, "
                    f"改进量: {improvement:.8f}"
                )

            if improvement < tol:
                if verbose:
                    print(f"收敛！改进量 {improvement:.8f} < 阈值 {tol}")
                break

            if not cycle_improved:
                if verbose:
                    print("无进一步改进，提前停止")
                break

        # 计算最终结果
        final_f = objective_func(x)

        result = {
            "x": x,
            "fun": final_f,
            "x_iters": np.array(X_iters),
            "func_vals": np.array(func_vals),
            "n_cycles": cycle + 1,
            "success": improvement < tol or not cycle_improved,
        }

        if verbose:
            print(f"\n优化完成！")
            print(f"最优解: {result['x']}")
            print(f"最优值: {result['fun']:.6f}")
            print(f"总轮次: {result['n_cycles']}")
            print(f"总函数评估次数: {len(func_vals)}")

        return result


class BlackBoxOptimizer:
    def genetic_algorithm(
        self,
        objective_func,
        bounds,
        early_stop_thresholds,
        early_stop_thresholds_output,
        population_size=50,
        generations=100,
        mutation_rate=0.1,
        crossover_rate=0.8,
        elite_ratio=0.2,
        early_stop_generations=10,
        use_precise_optimizer=True,
        random_state=None,
        verbose=True,
        callback=None,
        max_history_size=10,
        plot_convergence=True,
        save_plot=False,
        plot_filename="convergence.png",
    ):
        """
        遗传算法优化器，结合早停机制和精确优化器

        objective_func : callable
            目标函数，接受numpy数组作为输入，返回标量值
        bounds : list of tuples
            每个变量的搜索边界，格式为[(min1, max1), (min2, max2), ...]
        population_size : int, default=50
            种群大小
        generations : int, default=100
            最大进化代数
        mutation_rate : float, default=0.1
            变异概率
        crossover_rate : float, default=0.8
            交叉概率
        elite_ratio : float, default=0.2
            精英保留比例
        early_stop_generations : int, default=10
            早停检查的代数
        use_precise_optimizer : bool, default=True
            是否使用精确优化器进行最终优化
        random_state : int, default=None
            随机种子
        verbose : bool, default=True
            是否打印优化过程
        callback : callable, default=None
            每代后的回调函数
        max_history_size : int, default=50
            历史数据最大存储代数，防止内存过度占用
        plot_convergence : bool, default=True
            是否绘制收敛过程图
        save_plot : bool, default=False
            是否保存收敛图到文件
        plot_filename : str, default="convergence.png"
            保存的图片文件名

        result : dict
            优化结果
        """

        if random_state is not None:
            np.random.seed(random_state)

        self.early_stop_thresholds = early_stop_thresholds
        self.early_stop_thresholds_output = early_stop_thresholds_output
        dim = len(bounds)
        bounds = np.array(bounds)
        param_names = list(early_stop_thresholds.keys())
        thresholds = [early_stop_thresholds[name] for name in param_names]

        # 初始化种群
        population = self._initialize_population(population_size, bounds)
        fitness_history = []
        population_history = []
        best_individual_history = []

        # 用于绘制收敛过程的数据
        convergence_data = {
            "generation": [],
            "best_fitness": [],
            "avg_fitness": [],
            "std_fitness": [],
        }

        if verbose:
            print(f"开始遗传算法优化...")
            print(f"种群大小: {population_size}, 最大代数: {generations}")
            print(f"变异率: {mutation_rate}, 交叉率: {crossover_rate}")
            print(f"早停阈值: {dict(zip(param_names, thresholds))}")

        # 进化主循环
        for generation in range(generations):
            # 计算适应度
            time_start = time.time()
            # 使用缓存避免重复计算
            if not hasattr(self, "_fitness_cache"):
                self._fitness_cache = {}

            fitness = []
            cache_hits = 0
            cache_misses = 0

            for ind in population:
                # 创建缓存键（将参数值四舍五入到3位小数作为键）
                cache_key = tuple(np.round(ind, 3))

                if cache_key in self._fitness_cache:
                    fitness.append(self._fitness_cache[cache_key])
                    cache_hits += 1
                else:
                    # 检查是否有足够接近的值（误差小于0.001）
                    found_similar = False
                    for cached_key, cached_value in self._fitness_cache.items():
                        if np.allclose(
                            np.array(cache_key), np.array(cached_key), atol=0.001
                        ):
                            fitness.append(cached_value)
                            cache_hits += 1
                            found_similar = True
                            break

                    if not found_similar:
                        # 计算新的适应度值
                        fit_val = objective_func(ind)
                        fitness.append(fit_val)
                        self._fitness_cache[cache_key] = fit_val
                        cache_misses += 1

            fitness = np.array(fitness)

            if verbose and cache_hits > 0:
                print(
                    f"  缓存命中: {cache_hits}, 新计算: {cache_misses}, 缓存大小: {len(self._fitness_cache)}"
                )
            time_end = time.time()
            if verbose:
                print(
                    f"代 {generation+1}: 评估 {len(population)} 个体耗时 {time_end - time_start:.4f} 秒"
                )

            # 限制历史数据存储大小
            if len(fitness_history) >= max_history_size:
                fitness_history.pop(0)  # 移除最旧的记录
                population_history.pop(0)

            fitness_history.append(fitness.copy())
            population_history.append(population.copy())

            # 记录当前最优个体（也限制历史大小）
            best_idx = np.argmax(fitness)
            best_individual = population[best_idx].copy()
            best_fitness = fitness[best_idx]

            if len(best_individual_history) >= max_history_size:
                best_individual_history.pop(0)  # 移除最旧的记录

            best_individual_history.append((best_individual.copy(), best_fitness))

            # 记录收敛数据
            avg_fitness = np.mean(fitness)
            std_fitness = np.std(fitness)
            convergence_data["generation"].append(generation + 1)
            convergence_data["best_fitness"].append(best_fitness)
            convergence_data["avg_fitness"].append(avg_fitness)
            convergence_data["std_fitness"].append(std_fitness)

            if verbose:
                print(
                    f"第 {generation+1} 代: 最优={best_fitness:.6f}, "
                    f"平均={avg_fitness:.6f}, 标准差={std_fitness:.6f}, 种群数量={len(population)}"
                )
                print(f"参数: {dict(zip(param_names, best_individual))}")

            # 早停检查
            if generation >= early_stop_generations:
                should_stop, stop_reason = self._check_early_stop(
                    best_individual_history, thresholds, early_stop_generations
                )
                if should_stop:
                    if verbose:
                        print(f"早停触发: {stop_reason}")
                        print(f"在第 {generation+1} 代停止遗传算法")
                    break

            # 选择
            selected_indices = self._tournament_selection(fitness, population_size)
            selected_population = population[selected_indices]

            # 精英保留
            elite_count = int(population_size * elite_ratio)
            elite_indices = np.argsort(fitness)[-elite_count:]
            elite_population = population[elite_indices]

            # 交叉和变异
            new_population = []

            # 保留精英
            new_population.extend(elite_population)

            # 生成剩余个体
            while len(new_population) < population_size:
                remaining_slots = population_size - len(new_population)

                if (
                    np.random.random() < crossover_rate and remaining_slots >= 2
                ):  # 确保有足够空间容纳2个子代
                    # 交叉
                    parent1, parent2 = np.random.choice(
                        len(selected_population), 2, replace=False
                    )
                    child1, child2 = self._crossover(
                        selected_population[parent1],
                        selected_population[parent2],
                        bounds,
                    )
                    new_population.extend([child1, child2])
                else:
                    # 变异（只添加1个个体）
                    parent_idx = np.random.randint(len(selected_population))
                    child = self._mutate(
                        selected_population[parent_idx], bounds, mutation_rate
                    )
                    new_population.append(child)

            # 确保种群大小正确
            population = np.array(new_population[:population_size])

            # 回调函数
            if callback is not None:
                callback(best_individual, best_fitness, generation + 1)

        # 获取最终最优解
        final_fitness = np.array([objective_func(ind) for ind in population])
        best_idx = np.argmax(final_fitness)
        best_solution = population[best_idx]
        best_value = final_fitness[best_idx]

        # 使用精确优化器进行最终优化
        if use_precise_optimizer:
            if verbose:
                print(f"\n使用精确优化器进行最终优化...")
                print(f"遗传算法结果: {best_solution}, 函数值: {best_value:.6f}")

            # 创建精确优化器实例
            precise_optimizer = PreciseOptimizer()

            # 在最优解附近创建搜索边界，使用early_stop_thresholds作为搜索范围
            refined_bounds = []
            for i, (param_name, (low, high)) in enumerate(zip(param_names, bounds)):
                threshold = early_stop_thresholds[param_name]
                half_range = threshold / 2

                refined_low = max(low, best_solution[i] - half_range)
                refined_high = min(high, best_solution[i] + half_range)
                refined_bounds.append((refined_low, refined_high))

            try:
                if verbose:
                    print("bounds:", refined_bounds)
                precise_result = precise_optimizer.coordinate_optimization(
                    objective_func=objective_func,
                    bounds=refined_bounds,
                    tol=1e-3,
                    max_cycles=20,
                    verbose=verbose,
                )

                if precise_result["fun"] > best_value:
                    best_solution = precise_result["x"]
                    best_value = precise_result["fun"]
                    if verbose:
                        print(
                            f"精确优化改进: {best_solution}, 函数值: {best_value:.6f}"
                        )
                else:
                    if verbose:
                        print(f"精确优化未改进，保持遗传算法结果")

            except Exception as e:
                if verbose:
                    print(f"精确优化失败: {e}")
                    print(f"保持遗传算法结果")

        # 构建结果
        all_individuals = []
        all_fitness = []
        for pop, fit in zip(population_history, fitness_history):
            all_individuals.extend(pop)
            all_fitness.extend(fit)

        result = {
            "x": best_solution,
            "fun": best_value,
            "x_iters": np.array(all_individuals),
            "func_vals": np.array(all_fitness),
            "n_generations": generation + 1,
            "fitness_history": fitness_history,
            "best_history": best_individual_history,
        }

        if verbose:
            print(f"\n遗传算法优化完成！")
            print(f"最优解: {result['x']}")
            print(f"最优值: {result['fun']:.6f}")
            print(f"总进化代数: {result['n_generations']}")

        # 绘制收敛过程图
        if plot_convergence and len(convergence_data["generation"]) > 0:
            self._plot_convergence(convergence_data, save_plot, plot_filename)

        return result

    def _initialize_population(self, population_size, bounds):
        """初始化种群"""
        population = []
        for _ in range(population_size):
            individual = np.random.uniform(bounds[:, 0], bounds[:, 1])
            population.append(individual)
        return np.array(population)

    def _tournament_selection(self, fitness, population_size, tournament_size=3):
        """锦标赛选择"""
        selected_indices = []
        for _ in range(population_size):
            tournament_indices = np.random.choice(
                len(fitness), tournament_size, replace=False
            )
            winner_idx = tournament_indices[np.argmax(fitness[tournament_indices])]
            selected_indices.append(winner_idx)
        return np.array(selected_indices)

    def _crossover(self, parent1, parent2, bounds):
        """单点交叉"""
        crossover_point = np.random.randint(1, len(parent1))

        child1 = np.concatenate([parent1[:crossover_point], parent2[crossover_point:]])
        child2 = np.concatenate([parent2[:crossover_point], parent1[crossover_point:]])

        # 确保在边界内
        child1 = np.clip(child1, bounds[:, 0], bounds[:, 1])
        child2 = np.clip(child2, bounds[:, 0], bounds[:, 1])

        return child1, child2

    def _mutate(self, individual, bounds, mutation_rate):
        """高斯变异"""
        mutated = individual.copy()
        for i in range(len(individual)):
            if np.random.random() < mutation_rate:
                # 高斯变异，标准差为参数范围的10%
                param_range = bounds[i, 1] - bounds[i, 0]
                mutation_strength = param_range * 1
                mutated[i] += np.random.normal(0, mutation_strength)

                # 确保在边界内
                mutated[i] = np.clip(mutated[i], bounds[i, 0], bounds[i, 1])

        return mutated

    def _check_early_stop(self, best_history, thresholds, check_generations):
        """检查早停条件"""

        # 获取最近几代的最优个体
        recent_best = [item[0] for item in best_history[-check_generations:]]

        # 计算每个参数的波动范围
        recent_best = np.array(recent_best)
        param_ranges = np.max(recent_best, axis=0) - np.min(recent_best, axis=0)

        # 计算最优值的波动范围
        recent_values = [item[1] for item in best_history[-check_generations:]]
        value_range = np.max(recent_values) - np.min(recent_values)

        print("参数波动范围:", param_ranges)
        print("最优值波动范围:", value_range)

        # 检查最优值是否小于阈值
        if value_range < self.early_stop_thresholds_output:
            return True, "最优值波动小于阈值"

        # 检查是否所有参数的波动都小于阈值
        param_names = list(self.early_stop_thresholds.keys())
        stable_params = []

        for i, (param_name, threshold) in enumerate(zip(param_names, thresholds)):
            if param_ranges[i] < threshold:
                stable_params.append(param_name)

        if len(stable_params) == len(param_names):
            return True, f"所有参数波动小于阈值: {dict(zip(param_names, param_ranges))}"

        return False, ""

    def _plot_convergence(
        self, convergence_data, save_plot=False, plot_filename="convergence.png"
    ):
        """
        绘制遗传算法收敛过程图

        Parameters:
        convergence_data : dict
            包含收敛数据的字典
        save_plot : bool
            是否保存图片到文件
        plot_filename : str
            保存的文件名
        """
        import matplotlib.pyplot as plt

        # 设置中文字体支持
        plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "DejaVu Sans"]
        plt.rcParams["axes.unicode_minus"] = False

        # 创建图形和子图
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))

        generations = convergence_data["generation"]
        best_fitness = convergence_data["best_fitness"]
        avg_fitness = convergence_data["avg_fitness"]
        std_fitness = convergence_data["std_fitness"]

        # 第一个子图：最优值和平均值的收敛过程
        ax1.plot(
            generations,
            best_fitness,
            "r-",
            linewidth=2,
            label="最优值",
            marker="o",
            markersize=4,
        )
        ax1.plot(
            generations,
            avg_fitness,
            "b-",
            linewidth=2,
            label="平均值",
            marker="s",
            markersize=3,
        )

        # 添加标准差的阴影区域
        avg_fitness_array = np.array(avg_fitness)
        std_fitness_array = np.array(std_fitness)
        ax1.fill_between(
            generations,
            avg_fitness_array - std_fitness_array,
            avg_fitness_array + std_fitness_array,
            alpha=0.3,
            color="blue",
            label="标准差范围",
        )

        ax1.set_xlabel("进化代数")
        ax1.set_ylabel("适应度值")
        ax1.set_title("遗传算法收敛过程 - 适应度变化")
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 第二个子图：改进幅度
        if len(best_fitness) > 1:
            improvement = np.diff(best_fitness)
            ax2.plot(
                generations[1:],
                improvement,
                "g-",
                linewidth=2,
                label="改进幅度",
                marker="^",
                markersize=3,
            )
            ax2.axhline(y=0, color="k", linestyle="--", alpha=0.5)
            ax2.set_xlabel("进化代数")
            ax2.set_ylabel("适应度改进幅度")
            ax2.set_title("遗传算法收敛过程 - 每代改进幅度")
            ax2.legend()
            ax2.grid(True, alpha=0.3)
        else:
            ax2.text(
                0.5,
                0.5,
                "数据不足，无法显示改进幅度",
                transform=ax2.transAxes,
                ha="center",
                va="center",
                fontsize=12,
            )
            ax2.set_title("改进幅度图")

        # 添加统计信息文本
        final_best = best_fitness[-1] if best_fitness else 0
        initial_best = best_fitness[0] if best_fitness else 0
        total_improvement = final_best - initial_best

        stats_text = f"初始最优值: {initial_best:.6f}\n"
        stats_text += f"最终最优值: {final_best:.6f}\n"
        stats_text += f"总改进幅度: {total_improvement:.6f}\n"
        stats_text += f"总进化代数: {len(generations)}"

        # 在图上添加统计信息
        ax1.text(
            0.02,
            0.98,
            stats_text,
            transform=ax1.transAxes,
            verticalalignment="top",
            bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.8),
        )

        plt.tight_layout()

        # 保存图片
        if save_plot:
            plt.savefig(plot_filename, dpi=300, bbox_inches="tight")
            print(f"收敛图已保存为: {plot_filename}")

        plt.show()

        return fig


optimizer = BlackBoxOptimizer()


def T2_function(params):
    """
    适配贝叶斯优化器的目标函数
    params: numpy数组，包含[FY1_theta, t_drop, t_boom, v_FY1]
    """
    FY1_theta, t_drop, t_boom, v_FY1 = params
    try:
        t1 = GeneralN1(FY1_theta, t_drop, t_boom, v_FY1)
        _, _, duration = t1.find_t()
        # print("duration", duration)
        # 如果duration为None或异常值，返回0
        if duration is None or np.isnan(duration) or duration <= 0:
            # print("计算异常")
            return 0.0
        return duration
    except Exception as e:
        print(f"计算错误: {e}, 参数: {params}")
        return 0.0  # 异常情况返回0


optimizer = BlackBoxOptimizer()

bounds = [
    (0, np.pi),  # FY1_theta
    (0, 10),  # t_drop
    (0, 10),  # t_boom
    (70, 140),  # v_FY1
]
early_stop_thresholds = {"FY1_theta": 0.5, "t_drop": 1.0, "t_boom": 1.0, "v_FY1": 50.0}

result_ga = optimizer.genetic_algorithm(
    objective_func=T2_function,
    bounds=bounds,
    early_stop_thresholds=early_stop_thresholds,
    early_stop_thresholds_output=1.0,
    population_size=100,
    generations=100,
    mutation_rate=0.2,
    crossover_rate=0.7,
    elite_ratio=0.2,
    early_stop_generations=10,
    use_precise_optimizer=True,
    random_state=1,
    verbose=True,
    max_history_size=20,
)

print("\n遗传算法优化结果：")
print(
    f"最优参数: FY1_theta={result_ga['x'][0]:.6f}, t_drop={result_ga['x'][1]:.6f}, "
    f"t_boom={result_ga['x'][2]:.6f}, v_FY1={result_ga['x'][3]:.6f}"
)
print(f"最优遮蔽时间: {result_ga['fun']:.6f} 秒")
